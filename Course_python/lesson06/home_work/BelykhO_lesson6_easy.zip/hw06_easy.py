#!/usr/bin/env python
# -*- coding: utf-8 -*-

# Задача-1: Написать класс для фигуры-треугольника, заданного координатами трех точек.
# Определить методы, позволяющие вычислить: площадь, высоту и периметр фигуры.

import math

__author__ = 'belykh_olga'

class Figure:
    def __init__(self, a, b, c):
        self.a = a
        self.b = b
        self.c = c

    # Вычислим длины треугольника по координатам - la, lb, lc
    @property
    def la(self):
        la = math.sqrt((self.a[0] - self.b[0]) ** 2 + (self.a[1] - self.b[1]) ** 2)
        return la

    @property
    def lb(self):
        lb = math.sqrt((self.c[0] - self.b[0]) ** 2 + (self.c[1] - self.b[1]) ** 2)
        return lb

    @property
    def lc(self):
        lc = math.sqrt((self.c[0] - self.a[0]) ** 2 + (self.c[1] - self.a[1]) ** 2)
        return lc

    @property
    def angle(self):
        alfa = math.acos(((self.la ** 2 + self.lb ** 2 - self.lc ** 2) / (2 * self.la * self.lb)) * math.pi / 180)
        return alfa

    @property
    def p_triangle(self):
        p = round((self.la + self.lb + self.lc), 1)
        return 'Периметр треугольника {} см'.format(p)

    @property
    def area_triangle(self):
        s = round((0.5 * self.la * self.lb * math.sin(self.angle)), 1)
        return 'Площадь треугольника: {} см2'.format(s)

    @property
    def height(self):
        len_h = round((self.lb * math.sin(self.angle)), 1)
        return 'Высота треугольника равна: {} см'.format(len_h)


new = Figure((1, 0), (3, 5), (5, 0))

print new.area_triangle, new.height, new.p_triangle

# print new.lb, new.la, new.lc

# Задача-2: Написать Класс "Равнобочная трапеция", заданной координатами 4-х точек.
#  Предусмотреть в классе методы: проверка, является ли фигура равнобочной трапецией;
#  вычисления: длины сторон, периметр, площадь.

'''
    Рассмотрим трапецию вида:

        B  _______  C
         /         \
        /           \
    A  /_____________\  D     ось X


'''


class Trapez:
    def __init__(self, a, b, c, d):
        self.a = a
        self.b = b
        self.c = c
        self.d = d

    # Вычислим длины трапеции по координатам точек - AB, BC, CD, DA
    @property
    def ab(self):
        la = math.sqrt((self.a[0] - self.b[0]) ** 2 + (self.a[1] - self.b[1]) ** 2)
        return la

    @property
    def bc(self):
        lb = math.sqrt((self.c[0] - self.b[0]) ** 2 + (self.c[1] - self.b[1]) ** 2)
        return lb

    @property
    def cd(self):
        lc = math.sqrt((self.c[0] - self.d[0]) ** 2 + (self.c[1] - self.d[1]) ** 2)
        return lc

    @property
    def da(self):
        ld = math.sqrt((self.d[0] - self.a[0]) ** 2 + (self.d[1] - self.a[1]) ** 2)
        return ld

    # Найдем длины диагоналей
    @property
    def ac(self):
        dia = math.sqrt((self.c[0] - self.a[0]) ** 2 + (self.c[1] - self.a[1]) ** 2)
        return dia

    @property
    def bd(self):
        dia = math.sqrt((self.d[0] - self.b[0]) ** 2 + (self.d[1] - self.b[1]) ** 2)
        return dia

    @property
    def trap(self):
        if self.ac == self.bd:
            return 'Равнобедренная трапеция'
        else:
            return 'Не равнобедренная трапеция'

    @property
    def peri(self):
        return 'Периметр трапеции: {} см'.format(round((self.ab + self.bc + self.cd + self.da), 1))

    @property
    def area_trap(self):
        if self.ac == self.bd:
            # S = ((BC+DA)/2)*sqrt(4*(AB**2)-(BC-DA)**2)
            s = ((self.bc + self.da) / 2) * math.sqrt(4 * (self.ab**2) - (self.bc - self.da)**2)
            return 'Площадь равнобедренной трапеции: {} см'.format(s)
        else:
            return 'Не могу вычислить площадь данной фигуры'


tr = Trapez((0, 0), (5, 3), (5, 9), (0, 12))

print tr.peri, tr.trap, tr.area_trap
