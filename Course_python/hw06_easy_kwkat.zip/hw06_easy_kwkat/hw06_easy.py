#!/usr/bin/env python
# -*- coding: utf-8 -*-

import math
from decimal import Decimal

# Задача-1: Написать класс для фигуры-треугольника, заданного координатами трех точек.
# Определить методы, позволяющие вычислить: площадь, высоту и периметр фигуры.

PRECISION = Decimal('.00')


class Dot():

    def __init__(self, x, y):
        self.x = Decimal(x).quantize(PRECISION)
        self.y = Decimal(y).quantize(PRECISION)

    def __repr__(self):
        return '(x: {}, y: {})'.format(self.x, self.y)


class Side():

    def __init__(self, a, b):
        '''Принимает на вход два объекта класса Dot и назначает
        их как начальную и конечную точки отрезка'''
        self.a = a
        self.b = b

    @property
    def length(self):
        length = math.sqrt(
            abs((self.a.x - self.b.x)) ** 2 + abs((self.a.y - self.b.y)) ** 2)

        return Decimal(length).quantize(PRECISION)


class Polygon():

    def __init__(self, *arguments):
        self._dots = arguments

    @property
    def perimeter(self):
        return sum([s.length for s in self.sides])

    @property
    def sides(self):
        sides = []
        prev_dot = self.dots[-1]
        for dot in self.dots:
            sides.append(Side(prev_dot, dot))
            prev_dot = dot

        # возвращаю порядок сторон
        return sides[1:] + [sides[0]]

    @property
    def dots(self):
        return self._dots

    def get_sorting_side_length(self):
        sides = [side.length for side in self.sides]
        sides.sort()
        return sides


class Triangle(Polygon):

    def __init__(self, a, b, c):
        Polygon.__init__(a, b, c)

    def __eq__(self, another_triangle):
  
        sides1 = self.get_sorting_side_length()
        sides2 = another_triangle.get_sorting_side_length()
        
        return all([a == b for a, b in zip(sides1, sides2)])

    @property
    def height(self):
        self.base = self.sides[0]  # выбираю основание
        l_ab, l_bc, l_ca = self.sides[0].length, self.sides[
            1].length, self.sides[2].length
        p = (l_ab + l_bc + l_ca) / 2
        temp = math.sqrt(p * (p - l_ab) * (p - l_bc) * (p - l_ca))
        numerator = 2 * Decimal(temp).quantize(PRECISION)
        h = numerator / self.base.length
        return Decimal(h).quantize(PRECISION)

    @property
    def square(self):
        return ((self.height * self.base.length) / 2).quantize(PRECISION)

    @property
    def perimeter(self):
        return Polygon.perimeter


fff = Polygon(Dot(1, 3), Dot(1, 9))

print fff.perimeter



# Задача-2: Написать Класс "Равнобочная трапеция", заданной координатами 4-х точек.
#  Предусмотреть в классе методы: проверка, является ли фигура равнобочной трапецией;
#  вычисления: длины сторон, периметр, площадь.


class RightTrapeze(Polygon):

    def __init__(self, a, b, c, d):
        super().__init__(a, b, c, d)

    def is_right_trapeze(self):
        a, b, c, d = self.dots
        self.bases = []
        if Triangle(a, b, c) == Triangle(a, b, d):
            self.bases = [Side(a, b), Side(Side(c, d))]
            self.triange_on_base = Triangle(a, b, c)

        elif Triangle(a, d, c) == Triangle(a, d, b):
            self.bases = [Side(a, d), Side(b, c)]
            self.triange_on_base = Triangle(a, d, c)

        return True if self.bases else False

    def calc_height(self):
        if self.is_right_trapeze():
            return self.triange_on_base.height
        else:
            print('Фигура не является равнобочной трапецией')

    @property
    def height(self):
        return self.calc_height()

    @property
    def square(self):
        if self.is_right_trapeze():
            return (sum(map(lambda x: x.length, self.bases)) / 2) * self.height
        else:
            print('Фигура не является равнобочной трапецией')

    @property
    def perimeter(self):
        return super().perimeter

    
