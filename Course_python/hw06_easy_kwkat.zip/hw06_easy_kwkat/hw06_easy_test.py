
from decimal import Decimal
from triangle import Dot, Side, Triangle, Polygon, RightTrapeze, PRECISION

def test_dots():

    dot = Dot(2,3)
    assert dot.x == 2 and dot.y == 3
    print('class Dot work')


def test_sides():

    dot = Dot(2,3)
    side = Side(dot, Dot(2, 5))
    assert side.a.x == dot.x and side.a.y == dot.y and side.length == 2
    assert Side(Dot(0,3), Dot(3,0)).length == Decimal(4.242640687119285).quantize(PRECISION) 
    assert Side(Dot(1, 1), Dot(1, 1)).length == 0
    print('class Side work')


def test_polygon():

    polygon = Polygon(Dot(0, 0), Dot(0, 3), Dot(4, 3), Dot(4, 0))
    assert all([x.length == a for x, a in zip(polygon.sides, [3, 4, 3, 4])])
    assert polygon.perimeter == 14
    print('class Polygon work')


def test_triangle():

    triangle = Triangle(Dot(0, 3), Dot(0, 0), Dot(3, 0))
    assert triangle.square == Decimal(4.5).quantize(PRECISION)
    assert triangle.perimeter == Decimal(4.242640687119285).quantize(PRECISION) + 6
    assert triangle.height == Decimal(3).quantize(PRECISION)
    print('class Triangle work')


def test_trapeze():

    trapeze = RightTrapeze(Dot(0, 0), Dot(1,3), Dot(5,3), Dot(6,0))
    assert trapeze.is_right_trapeze()
    assert trapeze.height.quantize(PRECISION) == 3 
    assert trapeze.square.quantize(PRECISION) == 15

    trapeze2 = RightTrapeze(Dot(0, 0), Dot(1,3), Dot(5,8), Dot(6,0))
    assert not trapeze2.is_right_trapeze()
    # trapeze2.height
    print('class RightTrapeze work')


if __name__ == '__main__':
    test_dots()
    test_sides()
    test_polygon() 
    test_triangle()
    test_trapeze()

